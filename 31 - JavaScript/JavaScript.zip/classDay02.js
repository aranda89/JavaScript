//Aritimetic Operators
let num1 = 3
let num2 = 2

let total = num1 + num2

//                TV           v
// <> | >= | <= | === | !== | == | += | -= | *= | /=

//TV = Type and value | V = Value

//increment ++ - increase by only one value
//decrement -- - decrease by only one value

console.log(total)
console.log(++total)
console.log(total++)
console.log(--total)
console.log(total--)

console.log(num1 + num2)
console.log(num1 - num2)
console.log(num1 * num2)
console.log(num1 / num2)
console.log(num1 % num2)
console.log(num1 ** num2)


//Atribution Operator '='

       //|-> atribution
let num3 = 3

//Atribution Operator '=' + 'Aritimetic Operators'



